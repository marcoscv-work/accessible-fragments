const inputElement = document.getElementById(`${fragmentElementId}-checkbox`);

const preventClick = (event) => event.preventDefault();

if (inputElement) {
	if (input.readOnly) {
		inputElement.addEventListener('click', preventClick);
	}

	if (layoutMode === 'edit') {
		inputElement.setAttribute('disabled', true);
	}
	else {
		const defaultLanguageId = input.attributes.defaultLanguageId;

		import('@liferay/fragment-impl/api').then(
			({registerLocalizedInput, registerUnlocalizedInput}) => {
				if (input.localizable) {
					const {onChange} = registerLocalizedInput({
						availableLanguageIds:
							input.attributes.availableLanguageIds,
						changeTextDirection: false,
						defaultLanguageId,
						initialValues: input.valueI18n,
						inputElement,
						inputName: input.name,
						localizationInputsContainer: inputElement.parentNode,
						namespace: fragmentElementId,
					});

					inputElement.addEventListener('change', (event) => {
						onChange(event.target.checked);
					});
				}
				else {
					const unlocalizedFieldsState =
						input.attributes.unlocalizedFieldsState;

					registerUnlocalizedInput({
						changeTextDirection: false,
						defaultLanguageId,
						inputElement,
						onLocaleChange: (languageId) => {
							if (
								defaultLanguageId !== languageId &&
								unlocalizedFieldsState === 'read-only'
							) {
								inputElement.addEventListener(
									'click',
									preventClick
								);
							}
							else {
								inputElement.removeEventListener(
									'click',
									preventClick
								);
							}
						},
						readOnlyInputLabel: document.getElementById(
							`${fragmentElementId}-checkbox-read-only`
						),
						unlocalizedFieldsState,
						unlocalizedMessageContainer: document.getElementById(
							`${fragmentElementId}-unlocalized-info`
						),
					});
				}
			}
		);
	}
}
